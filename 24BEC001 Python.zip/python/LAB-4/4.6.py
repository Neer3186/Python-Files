for i in range(1,12):
    print(i," AM")
print("12 Noon")
for i in range(13,24):
    print(i," PM")
print("24 Midnight")