kg = 10
gram = kg*1000
print(gram)