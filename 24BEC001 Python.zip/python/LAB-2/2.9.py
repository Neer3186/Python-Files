no = float(input("Enter a number : "))
no = int(no)
print(type(no))
print(no)