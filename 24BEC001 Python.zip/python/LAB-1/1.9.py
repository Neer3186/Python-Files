Rs = 100
dollars = Rs/48
print(dollars)