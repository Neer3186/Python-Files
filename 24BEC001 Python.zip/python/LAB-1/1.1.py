a = 10
b = 10
c = a+b
print(c)