grams = 1000
kg = grams/1000
print(kg)