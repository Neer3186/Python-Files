a = 10
b = 5
print(a,b)
a = a+b
b = a-b
a = a-b
print(a,b)