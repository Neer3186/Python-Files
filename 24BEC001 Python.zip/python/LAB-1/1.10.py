dollars = 200
pound = dollars*48/70
print(pound)