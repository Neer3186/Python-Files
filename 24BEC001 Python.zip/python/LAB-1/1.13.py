byte = 10000000
kb = byte/1024
print(kb)
mb = kb/1024
print(mb)
gb = mb/1024
print(gb)