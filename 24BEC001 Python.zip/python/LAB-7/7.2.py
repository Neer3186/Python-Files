d1 = {1:"One"}
d2 = {}
if(len(d2)==0):
    print("Dictionary is empty.")
else:
    print("Dictionary is not empty. ", d2)