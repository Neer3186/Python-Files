l=1
b=2
if((l*b)>(2*(l+b))):
    print("Area of rectangle is greater")
else:
    print("Perimeter of rectangle is greater")
