a1 = int(input("Enter 1 angle : "))
a2 = int(input("Enter 2 angle : "))
a3 = int(input("Enter 3 angle : "))
if((a1+a2+a3)==180):
    print("Triangle is valid.")
else:
    print("Triangle is not valid.")