l = 10
b = 5
a = l*b
print(a)
p = 2*(l+b)
print(p)