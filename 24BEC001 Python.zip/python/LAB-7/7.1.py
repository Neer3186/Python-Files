d1 = {1:"One"}
d2 = {2:"Two"}
d3 = {3:"Three"}
d4 = {}
d4.update(d1)
d4.update(d2)
d4.update(d3)
print(d4)