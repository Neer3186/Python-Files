#Upper case alphabets code
for i in range(65,91):  #ASCII Value of A to Z is 65 to 90
    print(chr(i))       #chr() convert int to char

#lower case alphabets code
for i in range(97,123):  #ASCII Value of a to z is 97 to 123
    print(chr(i))       #chr() convert int to char