no = int(input("Enter a number : "))
digit = 0
while (no!=0):
    digit = digit + 1
    no = no//10
print(digit)