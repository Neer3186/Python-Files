a = 10
b = 9
c = 8
sum = a+b+c
print(sum)
avg = sum/3
print(avg)