x1 = 1
y1 = 1
x2 = 2
y2 = 2
x3 = 3
y3 = 4
if((y2-y1)/(x2-x1)==(y3-y2)/(x3-x2)):
    print("Three point are on same line.")
else:
    print("Three point are not on same line.")