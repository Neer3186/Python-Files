l1 = ["Ankur Don","Gugulu","Yem Marene","Vima Mali","Hitler","Varghaese","Cringe Joker"]
f = filter(lambda x:len(x)>=8,l1)
print(list(f))