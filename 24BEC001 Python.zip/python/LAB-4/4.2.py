# Multiplication table of input number
no = int(input("Enter a number for multiplication : "))
for i in range(1,11):
    print(no,"*",i,"=",no*i)