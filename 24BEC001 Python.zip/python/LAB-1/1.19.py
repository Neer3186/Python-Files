r = 10
a = 22/7*r*r
print(a)