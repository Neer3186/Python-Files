p = 10
r = 10
n = 10
i = p*r*n/100
print(i)