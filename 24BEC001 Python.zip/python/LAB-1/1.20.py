h = 10
l = 5
a = h*l/2
print(a)