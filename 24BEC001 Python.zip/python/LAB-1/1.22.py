gs = 1000
ns = gs-(10/100*gs)
print(ns)