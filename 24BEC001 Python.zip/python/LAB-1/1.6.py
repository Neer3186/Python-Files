hours = 4
minutes = hours*60
print(minutes)