def q1():
    f=open('1.csv','w')
    f.write("done")
    f.close()
q1()