minutes = 240
hours = minutes/60
print(hours)