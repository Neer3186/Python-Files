# code for printing N natural no. in reverse order

no = int(input("Enter a number : "))
for i in range(no,0,-1):
    print(i)