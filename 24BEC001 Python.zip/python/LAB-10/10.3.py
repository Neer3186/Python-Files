import os
def q3():
    print(os.path.exists('x'))
q3()