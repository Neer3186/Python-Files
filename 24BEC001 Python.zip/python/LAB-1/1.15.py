f = 10
c = 5/9*(f-32)
print(c)