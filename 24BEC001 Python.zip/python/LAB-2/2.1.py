a=5
b=10
if(a>b):
    print(a,"is largest")
    print(b,"is smallest")
else:
    print(b,"is largest")
    print(a,"is smallest")