age = int(input("Enter your year : "))
if(age>=18):
    print("Major")
else:
    print("Minor")