dollars = 10
Rs = dollars*48
print(Rs)