c = 100
f = (9*c/5)+32
print(f)