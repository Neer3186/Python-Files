gs = 1000
al = 10/100*gs
de = 3/100*gs
ns = gs+al-de
print(ns)