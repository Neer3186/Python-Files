a = 10
b = 10
c = a+b
print(c)
d = a-b
print(d)
e = a*b
print(e)
f = a/b
print(d)