l = 10
a = l*l
print(a)
p = 4*l
print(p)